// Arduino -> Hondex Library by Marcel v0.3 - 12/07/2019
// Copyright (c) 2019 - Not for commercial use unless given strict permission from the author. All right reserved.
// A library for sending signals to a Hondex plotter/sounder. A Hondex HE-7502 and Rigol DS1102E Oscilloscope were used to find the signals.
/* Functions for the signals are:
BrightUp, BrightDn
ZoomIn, ZoomOut
MarkCirc, MarkSqr
TrackStart, TrackStop
Menu, Set, Clr
NthUp, CseUp
Cursor, Refresh
Up, Dn, Lt, Rt
Ok, ModeA, ModeAB, ModeB
PwrOn, PwrOff
WakeTog
*/
#include "Arduino.h"
int pin = 10;
// Define the Ones and Zeros
void One(){
  digitalWrite(Pin, HIGH);
  delayMicroseconds(560);
  digitalWrite(Pin, LOW);
  delayMicroseconds(500);
}
void Zero(){
  digitalWrite(Pin, LOW);
  delayMicroseconds(1100);
}
// 4Bit Binary Blocks to make signal definitions easier
void R(){
  One();
  One();
  Zero();
  Zero();
}
void S(){
  Zero();
  One();
  One();
  Zero();
}
void T(){
  Zero();
  One();
  One();
  One();
}
void U(){
  One();
  One();
  One();
  Zero();
}
void V(){
  One();
  Zero();
  One();
  One();
}
void W(){
  One();
  One();
  Zero();
  One();
}
void X(){
  One();
  Zero();
  One();
  Zero();
}
void Y(){
  Zero();
  One();
  Zero();
  One();
}
void Z(){
  One();
  One();
  One();
  One();
}

// Trigger pulse for the beginning of all signals
void Trigger(){
  digitalWrite(10, HIGH);
  delayMicroseconds(8600);
  digitalWrite(10, LOW);
  delayMicroseconds(4200);
  W();
  T();
  W();
  V();
  Y();
  One();
  One();
  One();
}

//Hondex Remote - Button Signals
//Each signal ends with a delay of 225 milliseconds because that's the minimum delay for Hondex to keep up with

void BrightUp(){
  Trigger();
  Y();
  T();
  X();
  Z();
  Y();
  T();
  delay(225);
}
void BrightDn(){
  Trigger();
  X();
  Z();
  Y();
  T();
  Y();
  T();
  delay(225);
}
void ZoomOut(){
  Trigger();
  T();
  V();
  Y();
  X();
  V();
  T();
  delay(225);
}
void ZoomIn(){
  Trigger();
  Y();
  Y();
  W();
  T();
  W();
  T();
  delay(225);
}
void Up(){
  Trigger();
  W();
  W();
  Y();
  Y();
  X();
  Z();
  delay(225);
}
void Dn(){
  Trigger();
  X();
  U();
  X();
  V();
  X();
  Z();
  delay(225);
}
void Lt(){
  Trigger();
  Y();
  T();
  Y();
  T();
  X();
  Z();
  delay(225);
}
void Rt(){
  Trigger();
  S();
  U();
  X();
  W();
  X();
  Z();
  delay(225);
}
void PwrOn(){
  Trigger();
  V();
  U();
  X();
  W();
  Y();
  T();
  delay(225);
}
void PwrOff(){
  Trigger();
  T();
  U();
  V();
  Y();
  Y();
  T();
  delay(225);
}
void Menu(){
  Trigger();
  T();
  W();
  Y();
  X();
  X();
  Z();
  delay(225);
}
void Set(){
  Trigger();
  V();
  W();
  Y();
  S();
  X();
  Z();
  delay(225);
}
void Clr(){
  Trigger();
  Y();
  U();
  X();
  U();
  X();
  Z();
  delay(225);
}
void WakeTog(){
  Trigger();
  W();
  T();
  Y();
  Y();
  W();
  T();
  delay(225);
}
void ModeA(){
  Trigger();
  T();
  T();
  Y();
  X();
  W();
  T();
  delay(225);
}
void ModeAB(){
  Trigger();
  U();
  W();
  Y();
  Y();
  S();
  Z();
  delay(225);
}
void ModeB(){
  Trigger();
  U();
  U();
  X();
  X();
  W();
  T();
  delay(225);
}
void NthUp(){
  Trigger();
  Y();
  W();
  X();
  U();
  V();
  T();
  delay(225);
}
void CseUp(){
  Trigger();
  W();
  V();
  Y();
  Y();
  V();
  T();
  delay(225);
}
void Refresh(){
  Trigger();
  T();
  S();
  X();
  W();
  S();
  Z();
  delay(225);
}
void TrackStart(){
  Trigger();
  Y();
  X();
  W();
  T();
  T();
  T();
  delay(225);
}
void TrackStop(){
  Trigger();
  S();
  X();
  W();
  S();
  Z();
  T();
  delay(225);
}
void MarkCirc(){
  Trigger();
  V();
  V();
  Y();
  S();
  V();
  T();
  delay(225);
}
void MarkSqr(){
  Trigger();
  S();
  W();
  X();
  W();
  V();
  T();
  delay(225);
}
void Cursor(){
  Trigger();
  X();
  V();
  X();
  V();
  W(); 
  T();
  delay(225);
}
#ifndef Hondex_h
#define Hondex_h

// That's all! 12/07/2019

#endif